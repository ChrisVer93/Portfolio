"""Generate real MAT level-5 fixtures using SciPy; no MATLAB runtime needed."""
from pathlib import Path
import numpy as np
from scipy.io import savemat
base=Path(__file__).parent/'fixtures'
base.mkdir(exist_ok=True)
curve={'characteristicId':'Qrr_di_dt_f_Tj_If','axisMeta':{'xUnit':'A/us','yUnit':'nC','depUnits':np.array(['degC','A'],dtype=object)},'iterations':np.array([{'x':np.array([0,100,200]),'y':np.array([0,50,100]),'depNames':np.array(['Tj','If'],dtype=object),'depValues':np.array([100,10])}],dtype=object)}
for compression in [False,True]:
 savemat(base/f'curve_{"compressed" if compression else "plain"}.mat',{'curve':curve},do_compression=compression)
savemat(base/'wave_numeric.mat',{'wave':np.column_stack([np.arange(5)/10000,np.full(5,400.),np.full(5,10.)])},do_compression=True)
