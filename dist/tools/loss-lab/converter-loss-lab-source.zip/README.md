# Converter Loss Lab
A browser-based port of Christian Verrecchia's MATLAB converter-loss workflow.

## Use
Open the deployed private Site. The app starts with clearly labelled synthetic
buck-converter data. Run analysis, then inspect Results & reports. Use New study
for your own converter; import waveforms, add devices, assign curves and signal
mappings, set the operating power pairs, then run.

- CSV/TXT: header row plus numeric time/voltage/current columns. Confirm units.
- MAT: level-5 numeric matrices and primitive curve structs are read locally,
  including compression. Name matrix columns during import.
- MATLAB tables, opaque objects and v7.3: run the supplied helper in MATLAB:
  `export_loss_tool_web('snapshot.mat','web_project.json')`, then Open project.
  For a waveform table JSON, use Import files instead.
- Curve MAT files: select the candidate's Curves tab and Import MAT / JSON.
- Image curves: choose Curve digitiser, upload a datasheet image, calibrate three
  axis references, sample points, choose units and dependencies, add iterations.
- Save project downloads a portable JSON including waveforms/models/provenance.
- Report downloads self-contained HTML; open it and print to PDF if needed.

Files and calculations remain local to the browser. Browser autosave has a
quota; use the downloadable project for portable, durable personal copies.
Results are invalidated when calculation inputs change.

## Run locally
No dependencies or build step are required.

```
python3 -m http.server 8080 --directory dist
```

Open http://localhost:8080. ES modules and the computation worker require HTTP;
do not double-click index.html as a file URL.

## Tests
Node 22 or newer:

```
node --test tests/engine.test.mjs
```

MAT fixtures are bundled. To regenerate them, run
`python3 tests/generate_fixtures.py` with NumPy and SciPy installed.

79 analytic/numerical/import tests passed. There was no MATLAB runtime or real
project dataset supplied, so exact MATLAB parity and hardware accuracy remain
unverified. Browser visual/interaction QA could not be run in the available
managed environment; static checks and numerical/import tests were performed.

## Source
- dist/engine.js: pure numerical engine
- dist/io.js: import, MATLAB compatibility, schemas and demo fixtures
- dist/app.js: editor, image digitiser, plots and exports
- dist/worker.js: calculation worker
- dist/export_loss_tool_web.m: MATLAB-to-JSON export helper (not run in MATLAB here)
- tests/: analytic regression tests and real MAT format fixtures
- dist/FEATURES.md: full feature matrix and limitations

Sparse dependency interpolation intentionally uses the documented web policy;
it is not guaranteed to reproduce MATLAB's triangulation. Models for core loss,
reverse recovery and thermal coupling retain explicit engineering limits.
