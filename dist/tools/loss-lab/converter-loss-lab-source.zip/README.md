# Converter Loss Lab

Serve `dist` using a static HTTP server, for example `python -m http.server 8080 --directory dist`, then open http://localhost:8080. No ChatGPT or backend service is required. Run `npm test` with Node 22 or newer.

See dist/FEATURES.md and dist/verification.json for model scope and verification limits.
