# Converter Loss Lab

Serve dist using `python -m http.server 8080 --directory dist`, then open http://localhost:8080. No ChatGPT or backend service required. Run npm test with Node 22+. See dist/FEATURES.md and dist/verification.json.
