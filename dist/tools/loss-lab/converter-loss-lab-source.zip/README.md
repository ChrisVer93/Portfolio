Converter Loss Lab 1.7.0

Serve with: python -m http.server 8080 --directory dist

Tests: Node 22, npm test
