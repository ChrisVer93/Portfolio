Converter Loss Lab 2.0.0
Serve: python -m http.server 8080 --directory dist
Tests: Node 22, npm test
