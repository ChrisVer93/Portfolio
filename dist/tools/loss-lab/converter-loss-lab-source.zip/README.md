# Converter Loss Lab — engine 1.1.0

Serve dist/ over HTTP. Run npm test with Node 22 or later. See dist/FEATURES.md for model coverage and assumptions.
