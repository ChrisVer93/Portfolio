Converter Loss Lab 1.8.0

Serve: python -m http.server 8080 --directory dist
Tests: Node 22, npm test
